import React from "react";
import IndexPage from "./index";

export default function AppPage() {
  // /app просто рендерит тот же компонент (для демо редиректа из API)
  return <IndexPage />;
}